<template>
  <div class="userhome">
  <h3>{{ $route.params.id }}'s Home</h3>
  <p>this is the homepage of {{ $route.params.id }}...</p>
</div>
</template>

<script>
  export default{}
</script>
