<template>
  <div id="app">
    <img src="./assets/logo.png">
    <p>
      <!-- use router-link component for navigation. -->
      <!-- specify the link by passing the `to` prop. -->
      <!-- <router-link> will be rendered as an `<a>` tag by default -->
      <router-link to="/">Default</router-link>
      <router-link to="/home">Home</router-link>
      <router-link to="/element">Element</router-link>
      <router-link to="/user/YT">User</router-link>
      <router-link to="/user/YT/profile">Profile</router-link>
      <router-link to="/user/YT/posts">Posts</router-link>
    </p>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
