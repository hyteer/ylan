<template>
  <div class="posts">
  <h3>{{ $route.params.id }}'s Posts</h3>
  <p>below is the posts of {{ $route.params.id }}...</p>
</div>
</template>

<script>
  export default{}
</script>
