<template>
  <div class="profile">
  <h3>{{ $route.params.id }}'s Profile</h3>
  <p>this is the profile of {{ $route.params.id }}...</p>
</div>
</template>

<script>
  export default{}
</script>
